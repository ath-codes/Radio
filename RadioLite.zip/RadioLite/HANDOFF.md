# Radio Lite – handoff
Phase 1 done: build setup, service fixes, manifest, stations.json, basic list UI.
Next: P2 full UI (theme, tabs, states), P3 mini/full player + live indicators, P4 timer UI/favorites/search, P5 polish.
Stations with empty url show as "unavailable": fill real stream URLs in stations.json (bump "version").
Set stationsUrl in gradle.properties to the raw GitHub URL of stations.json.

## Update (links + podcasts)
- stations.json v2: real links added. Links with expiring tokens (zt=/rj-tok) were replaced by plain stream URLs (unverified: Umm Kulthum, Abdel Halim, Saudi Quran, Cairo Quran).
- podcasts.json added (RSS feeds). Phase 4 builds the RSS parser + Podcast tab. Still missing RSS: Mark Leonard, Butterfly Stompers, Rabbit Hole Detectives, Off Menu.
- Added media3-exoplayer-hls (needed for .m3u8 e.g. Al Jazeera).
- UI plan: country tabs + genre chips (all/news/quran/music/sport/talk).

## Phase 2 done (UI)
Files: Theme.kt (colors, genre colors), PlayerState.kt (player mirror + Status), Components.kt (Equalizer, StationCard, GenreChip, MiniPlayer, TimerButton w/ dropdown), MainActivity.kt.
Done: country tabs, genre chips, animated equalizer on playing card, live/connecting/retrying status, mini player with play/pause + sleep timer menu.
Next: P3 full player screen; P4 podcasts (RSS parser, episodes, seek, speed, resume); P5 favorites/search; P6 polish. Code has NOT been compiled yet: fix any build errors from the first GitHub Actions run.
