# Radio Lite – handoff
Phase 1 done: build setup, service fixes, manifest, stations.json, basic list UI.
Next: P2 full UI (theme, tabs, states), P3 mini/full player + live indicators, P4 timer UI/favorites/search, P5 polish.
Stations with empty url show as "unavailable": fill real stream URLs in stations.json (bump "version").
Set stationsUrl in gradle.properties to the raw GitHub URL of stations.json.

## Update (links + podcasts)
- stations.json v2: real links added. Links with expiring tokens (zt=/rj-tok) were replaced by plain stream URLs (unverified: Umm Kulthum, Abdel Halim, Saudi Quran, Cairo Quran).
- podcasts.json added (RSS feeds). Phase 4 builds the RSS parser + Podcast tab. Still missing RSS: Mark Leonard, Butterfly Stompers, Rabbit Hole Detectives, Off Menu.
- Added media3-exoplayer-hls (needed for .m3u8 e.g. Al Jazeera).
- UI plan: country tabs + genre chips (all/news/quran/music/sport/talk).

## Phase 2 done (UI)
Files: Theme.kt (colors, genre colors), PlayerState.kt (player mirror + Status), Components.kt (Equalizer, StationCard, GenreChip, MiniPlayer, TimerButton w/ dropdown), MainActivity.kt.
Done: country tabs, genre chips, animated equalizer on playing card, live/connecting/retrying status, mini player with play/pause + sleep timer menu.
Next: P3 full player screen; P4 podcasts (RSS parser, episodes, seek, speed, resume); P5 favorites/search; P6 polish. Code has NOT been compiled yet: fix any build errors from the first GitHub Actions run.

## Phase 4 done (podcasts, v0.2)
- Bottom nav Radio/Podcasts; tabs by content (news/quran/talk/sport/music · geopolitics/world/history_philosophy).
- RSS parser (XmlPullParser) with manual http<->https redirects, stable episode ids (hash of audio URL), 35 latest episodes.
- Podcast player: seek bar (always LTR), -15s/+30s, speed 1/1.25/1.5/2x, resume position (ResumeStore), ended state.
- PlaybackService: cross-protocol redirects allowed, podcast retry keeps position, stops after 6 failed retries, saves position every 5s.
- Remote stations.json is ignored if its version < bundled version.
- tools/check_links.py checks all stream + RSS links (needs internet; run locally).
- Unverified feeds: p-fareed-gps (chtbl link), p-rabbit-hole, p-ignore-feeling, p-meidastouch. Not compiled yet.
