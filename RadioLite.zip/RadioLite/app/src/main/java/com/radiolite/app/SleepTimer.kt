package com.radiolite.app

import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/** Process-wide sleep timer. [endsAt] is elapsedRealtime based (0 = off). */
object SleepTimer {
    val endsAt = MutableStateFlow(0L)
    var onFire: (() -> Unit)? = null
    var onCancel: (() -> Unit)? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null

    fun start(minutes: Int) {
        job?.cancel()
        onCancel?.invoke()
        val ms = minutes * 60_000L
        endsAt.value = SystemClock.elapsedRealtime() + ms
        job = scope.launch {
            delay(ms)
            endsAt.value = 0L
            onFire?.invoke()
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        endsAt.value = 0L
        onCancel?.invoke()
    }
}
