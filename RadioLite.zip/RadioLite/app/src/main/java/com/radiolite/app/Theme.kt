package com.radiolite.app

import androidx.annotation.StringRes
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B0E14)
val Card = Color(0xFF131925)
val CardOn = Color(0xFF14232A)
val Line = Color(0xFF1F2837)
val Accent = Color(0xFF2DD4BF)
val Muted = Color(0xFF8B96A8)
val LiveRed = Color(0xFFFF5D5D)

fun genreColor(g: String): Color = when (g) {
    "news" -> Color(0xFF60A5FA)
    "quran" -> Color(0xFF34D399)
    "music" -> Color(0xFFF472B6)
    "sport" -> Color(0xFFFB923C)
    "talk" -> Color(0xFFA78BFA)
    else -> Color(0xFF94A3B8)
}

@StringRes
fun genreLabel(g: String): Int = when (g) {
    "all" -> R.string.g_all
    "news" -> R.string.g_news
    "quran" -> R.string.g_quran
    "music" -> R.string.g_music
    "sport" -> R.string.g_sport
    "talk" -> R.string.g_talk
    else -> R.string.g_general
}
