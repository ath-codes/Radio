package com.radiolite.app

import android.content.Context
import android.content.SharedPreferences
import androidx.media3.common.Player

/** Remembers where each podcast episode stopped (episode ids start with "ep_"). */
object ResumeStore {
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs == null) prefs = ctx.applicationContext.getSharedPreferences("resume", Context.MODE_PRIVATE)
    }

    fun get(id: String): Long = prefs?.getLong(id, 0L) ?: 0L

    fun clear(id: String) { prefs?.edit()?.remove(id)?.apply() }

    /** Save the current position of [p] if it is playing a podcast episode. */
    fun save(p: Player) {
        val id = p.currentMediaItem?.mediaId ?: return
        if (!id.startsWith("ep_")) return
        val d = p.duration
        val pos = p.currentPosition
        val sp = prefs ?: return
        if (d > 0 && pos > d - 15_000) {
            sp.edit().remove(id).apply()
        } else if (pos > 5_000) {
            // keep the store small: drop oldest entries beyond 150
            val e = sp.edit()
            if (sp.all.size > 150) sp.all.keys.take(50).forEach { e.remove(it) }
            e.putLong(id, pos).apply()
        }
    }
}
