package com.radiolite.app

import android.os.SystemClock
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private fun DrawScope.bars(color: Color, h1: Float, h2: Float, h3: Float) {
    val w = size.width / 5f
    listOf(h1, h2, h3).forEachIndexed { i, h ->
        val bh = size.height * h
        drawRoundRect(color, Offset(i * 2 * w, size.height - bh), Size(w, bh), CornerRadius(w / 2))
    }
}

@Composable
fun Equalizer(color: Color, animate: Boolean) {
    if (animate) {
        val t = rememberInfiniteTransition(label = "eq")
        val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse), label = "a")
        val b by t.animateFloat(0.25f, 0.9f, infiniteRepeatable(tween(560, easing = LinearEasing), RepeatMode.Reverse), label = "b")
        val c by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(340, easing = LinearEasing), RepeatMode.Reverse), label = "c")
        Canvas(Modifier.size(20.dp)) { bars(color, a, b, c) }
    } else {
        Canvas(Modifier.size(20.dp)) { bars(color, 0.4f, 0.75f, 0.5f) }
    }
}

@Composable
fun PlayPauseButton(playing: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(52.dp).clip(CircleShape).background(Accent).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(20.dp)) {
            if (playing) {
                val w = size.width * 0.3f
                drawRoundRect(Bg, Offset(size.width * 0.1f, 0f), Size(w, size.height), CornerRadius(3f))
                drawRoundRect(Bg, Offset(size.width * 0.6f, 0f), Size(w, size.height), CornerRadius(3f))
            } else {
                val p = Path().apply {
                    moveTo(size.width * 0.18f, 0f)
                    lineTo(size.width, size.height / 2f)
                    lineTo(size.width * 0.18f, size.height)
                    close()
                }
                drawPath(p, Bg)
            }
        }
    }
}

@Composable
fun GenreChip(text: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(if (selected) color.copy(alpha = 0.18f) else Card, shape)
            .border(1.dp, if (selected) color else Line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(text, color = if (selected) color else Muted, fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
fun StationCard(
    name: String, genre: String, playable: Boolean, selected: Boolean,
    playing: Boolean, status: Status?, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    val gc = genreColor(genre)
    Row(
        Modifier.fillMaxWidth()
            .background(if (selected) CardOn else Card, shape)
            .border(1.dp, if (selected) Accent.copy(alpha = 0.55f) else Line, shape)
            .clip(shape)
            .clickable(enabled = playable, onClick = onClick)
            .padding(14.dp)
            .alpha(if (playable) 1f else 0.5f),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).background(gc.copy(alpha = 0.16f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) { Equalizer(gc, animate = selected && playing) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = if (selected) Accent else Color.White, fontSize = 16.sp,
                fontWeight = FontWeight.Medium, maxLines = 1)
            Spacer(Modifier.height(2.dp))
            if (!playable) {
                Text(stringResource(R.string.unavailable), color = Muted, fontSize = 12.sp)
            } else if (selected && status != null) {
                StatusText(status)
            } else {
                Text(stringResource(genreLabel(genre)), color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun StatusText(status: Status) {
    val (label, color) = when (status) {
        Status.Live -> R.string.st_live to LiveRed
        Status.Connecting -> R.string.st_connecting to Muted
        Status.Retrying -> R.string.st_retrying to Color(0xFFFBBF24)
        Status.Paused -> R.string.st_paused to Muted
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (status == Status.Live) {
            val t = rememberInfiniteTransition(label = "dot")
            val a by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a")
            Box(Modifier.size(7.dp).alpha(a).background(LiveRed, CircleShape))
            Spacer(Modifier.width(6.dp))
        }
        Text(stringResource(label), color = color, fontSize = 12.sp)
    }
}

@Composable
fun TimerButton() {
    val endsAt by SleepTimer.endsAt.collectAsState()
    var open by remember { mutableStateOf(false) }
    var left by remember { mutableLongStateOf(0L) }
    LaunchedEffect(endsAt) {
        while (endsAt != 0L) {
            left = (endsAt - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
            delay(1000)
        }
    }
    val active = endsAt != 0L
    val shape = RoundedCornerShape(50)
    Box {
        Box(
            Modifier.clip(shape).background(Bg, shape)
                .border(1.dp, if (active) Accent else Line, shape)
                .clickable { open = true }
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            val text = if (active) "%d:%02d".format(left / 60000, (left / 1000) % 60)
            else stringResource(R.string.timer_label)
            Text(text, color = if (active) Accent else Muted, fontSize = 12.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.background(Card)) {
            listOf(15, 30, 60, 90).forEach { m ->
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.timer_min, m), color = Color.White) },
                    onClick = { SleepTimer.start(m); open = false }
                )
            }
            if (active) DropdownMenuItem(
                text = { Text(stringResource(R.string.timer_cancel), color = LiveRed) },
                onClick = { SleepTimer.cancel(); open = false }
            )
        }
    }
}

@Composable
fun MiniPlayer(name: String, status: Status, wantsPlay: Boolean, onToggle: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier.fillMaxWidth().padding(12.dp).navigationBarsPadding()
            .background(Card, shape).border(1.dp, Line, shape).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            StatusText(status)
        }
        TimerButton()
        Spacer(Modifier.width(12.dp))
        PlayPauseButton(playing = wantsPlay, onClick = onToggle)
    }
}
