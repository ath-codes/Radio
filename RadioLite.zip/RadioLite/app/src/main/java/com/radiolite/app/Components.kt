package com.radiolite.app

import android.os.SystemClock
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

fun categoryLabelText(cat: String, ar: Boolean): String = when (cat) {
    "all" -> if (ar) "الكل" else "All"
    "news" -> if (ar) "الأخبار" else "News"
    "quran" -> if (ar) "القرآن الكريم" else "Quran"
    "talk" -> if (ar) "حوار وثقافة" else "Talk"
    "sport" -> if (ar) "رياضة" else "Sport"
    "music" -> if (ar) "موسيقى وطرب" else "Music"
    "geopolitics" -> if (ar) "جيوسياسة ودولية" else "Geopolitics"
    "world" -> if (ar) "أحوال العالم" else "World Affairs"
    "history_philosophy" -> if (ar) "تاريخ وفلسفة" else "History & Philosophy"
    else -> cat
}

fun categoryColorExt(cat: String): Color = when (cat) {
    "geopolitics" -> Color(0xFF38BDF8)
    "world" -> Color(0xFFF59E0B)
    "history_philosophy" -> Color(0xFFA855F7)
    else -> genreColor(cat)
}

private fun initials(name: String): String {
    val skip = setOf("the", "a", "an")
    val words = name.trim().split(Regex("\\s+"))
        .filter { it.lowercase() !in skip && it.any(Char::isLetterOrDigit) }
    return when {
        words.isEmpty() -> "?"
        words.size == 1 -> words[0].take(2).uppercase()
        else -> "${words[0].first()}${words[1].first()}".uppercase()
    }
}

private fun speedLabel(s: Float): String =
    if (s % 1f == 0f) "${s.toInt()}x" else "${s}x"

private fun DrawScope.bars(color: Color, h1: Float, h2: Float, h3: Float) {
    val w = size.width / 5f
    listOf(h1, h2, h3).forEachIndexed { i, h ->
        val bh = size.height * h
        drawRoundRect(color, Offset(i * 2 * w, size.height - bh), Size(w, bh), CornerRadius(w / 2))
    }
}

@Composable
fun Equalizer(color: Color, animate: Boolean) {
    if (animate) {
        val t = rememberInfiniteTransition(label = "eq")
        val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse), label = "a")
        val b by t.animateFloat(0.25f, 0.9f, infiniteRepeatable(tween(560, easing = LinearEasing), RepeatMode.Reverse), label = "b")
        val c by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(340, easing = LinearEasing), RepeatMode.Reverse), label = "c")
        Canvas(Modifier.size(20.dp)) { bars(color, a, b, c) }
    } else {
        Canvas(Modifier.size(20.dp)) { bars(color, 0.4f, 0.75f, 0.5f) }
    }
}

@Composable
fun PlayPauseButton(playing: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(48.dp).clip(CircleShape).background(Accent).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(18.dp)) {
            if (playing) {
                val w = size.width * 0.3f
                drawRoundRect(Bg, Offset(size.width * 0.1f, 0f), Size(w, size.height), CornerRadius(3f))
                drawRoundRect(Bg, Offset(size.width * 0.6f, 0f), Size(w, size.height), CornerRadius(3f))
            } else {
                val p = Path().apply {
                    moveTo(size.width * 0.18f, 0f)
                    lineTo(size.width, size.height / 2f)
                    lineTo(size.width * 0.18f, size.height)
                    close()
                }
                drawPath(p, Bg)
            }
        }
    }
}

@Composable
fun GenreChip(text: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(if (selected) color.copy(alpha = 0.18f) else Card, shape)
            .border(1.dp, if (selected) color else Line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text, color = if (selected) color else Muted, fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
fun StationCard(
    name: String, category: String, ar: Boolean, playable: Boolean, selected: Boolean,
    playing: Boolean, status: Status?, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    val gc = categoryColorExt(category)
    Row(
        Modifier.fillMaxWidth()
            .background(if (selected) CardOn else Card, shape)
            .border(1.dp, if (selected) Accent.copy(alpha = 0.55f) else Line, shape)
            .clip(shape)
            .clickable(enabled = playable, onClick = onClick)
            .padding(14.dp)
            .alpha(if (playable) 1f else 0.5f),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).background(gc.copy(alpha = 0.16f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) { Equalizer(gc, animate = selected && playing) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                name, color = if (selected) Accent else Color.White, fontSize = 16.sp,
                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            if (!playable) {
                Text(stringResource(R.string.unavailable), color = Muted, fontSize = 12.sp)
            } else if (selected && status != null) {
                StatusText(status, isPodcast = false, ar = ar)
            } else {
                Text(categoryLabelText(category, ar), color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun PodcastShowCard(show: PodcastShow, ar: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val c = categoryColorExt(show.category)
    Row(
        Modifier.fillMaxWidth()
            .background(Card, shape)
            .border(1.dp, Line, shape)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(48.dp).background(c.copy(alpha = 0.18f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = initials(show.name(ar)),
                color = c, fontSize = 16.sp, fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                show.name(ar), color = Color.White, fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            Text(categoryLabelText(show.category, ar), color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text(
            text = if (ar) "الحلقات ◂" else "Episodes ▸",
            color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun EpisodeCard(
    ep: Episode, selected: Boolean, playing: Boolean, status: Status?, ar: Boolean, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val resumed = remember(ep.id, selected) { if (selected) 0L else ResumeStore.get(ep.id) }
    Row(
        Modifier.fillMaxWidth()
            .background(if (selected) CardOn else Card, shape)
            .border(1.dp, if (selected) Accent.copy(alpha = 0.55f) else Line, shape)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).background(Accent.copy(alpha = 0.15f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Equalizer(Accent, animate = selected && playing)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                ep.title, color = if (selected) Accent else Color.White,
                fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(6.dp))
            if (selected && status != null) {
                StatusText(status, isPodcast = true, ar = ar)
            } else {
                val parts = listOf(ep.pubDate, ep.duration).filter { it.isNotBlank() }.toMutableList()
                if (resumed > 0L) parts += (if (ar) "توقفت عند ${formatMs(resumed)}" else "Stopped at ${formatMs(resumed)}")
                val meta = parts.joinToString(" • ")
                if (meta.isNotBlank()) Text(meta, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun StatusText(status: Status, isPodcast: Boolean = false, ar: Boolean = true) {
    if (isPodcast && status == Status.Live) {
        Text(if (ar) "قيد التشغيل الآن" else "Now Playing", color = Accent, fontSize = 12.sp)
        return
    }
    val (label, color) = when (status) {
        Status.Live -> R.string.st_live to LiveRed
        Status.Connecting -> R.string.st_connecting to Muted
        Status.Retrying -> R.string.st_retrying to Color(0xFFFBBF24)
        Status.Paused -> R.string.st_paused to Muted
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (status == Status.Live) {
            val t = rememberInfiniteTransition(label = "dot")
            val a by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a")
            Box(Modifier.size(7.dp).alpha(a).background(LiveRed, CircleShape))
            Spacer(Modifier.width(6.dp))
        }
        Text(stringResource(label), color = color, fontSize = 12.sp)
    }
}

@Composable
fun TimerButton() {
    val endsAt by SleepTimer.endsAt.collectAsState()
    var open by remember { mutableStateOf(false) }
    var left by remember { mutableLongStateOf(0L) }
    LaunchedEffect(endsAt) {
        while (endsAt != 0L) {
            left = (endsAt - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
            delay(1000)
        }
    }
    val active = endsAt != 0L
    val shape = RoundedCornerShape(50)
    Box {
        Box(
            Modifier.clip(shape).background(Bg, shape)
                .border(1.dp, if (active) Accent else Line, shape)
                .clickable { open = true }
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            val text = if (active) "%d:%02d".format(left / 60000, (left / 1000) % 60)
            else stringResource(R.string.timer_label)
            Text(text, color = if (active) Accent else Muted, fontSize = 11.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.background(Card)) {
            listOf(15, 30, 60, 90).forEach { m ->
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.timer_min, m), color = Color.White) },
                    onClick = { SleepTimer.start(m); open = false }
                )
            }
            if (active) DropdownMenuItem(
                text = { Text(stringResource(R.string.timer_cancel), color = LiveRed) },
                onClick = { SleepTimer.cancel(); open = false }
            )
        }
    }
}

@Composable
private fun PillButton(text: String, active: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(Bg, shape)
            .border(1.dp, if (active) Accent else Line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(text, color = if (active) Accent else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

fun formatMs(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0L)
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

@Composable
fun MiniPlayer(name: String, ps: PlayerState, ar: Boolean) {
    LaunchedEffect(ps.playing, ps.currentId) {
        while (ps.playing) {
            ps.syncProgress()
            delay(1000)
        }
    }
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            .background(Card, shape).border(1.dp, Line, shape).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    name.ifBlank { ps.title }, color = Color.White, fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                if (ps.isPodcast && ps.subtitle.isNotBlank()) {
                    Text(ps.subtitle, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(2.dp))
                }
                StatusText(ps.status, isPodcast = ps.isPodcast, ar = ar)
            }
            TimerButton()
            Spacer(Modifier.width(10.dp))
            PlayPauseButton(playing = ps.wantsPlay && !ps.ended, onClick = { ps.toggle() })
        }

        if (ps.isPodcast) {
            if (ps.duration > 0L) {
                val shown = if (dragging) dragValue else ps.position.toFloat().coerceIn(0f, ps.duration.toFloat())
                // time axis is always left-to-right, even in Arabic
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Spacer(Modifier.height(6.dp))
                    Slider(
                        value = shown,
                        onValueChange = { dragging = true; dragValue = it },
                        onValueChangeFinished = { ps.seekTo(dragValue.toLong()); dragging = false },
                        valueRange = 0f..ps.duration.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = Accent,
                            activeTrackColor = Accent,
                            inactiveTrackColor = Line
                        ),
                        modifier = Modifier.fillMaxWidth().height(32.dp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(formatMs(shown.toLong()), color = Muted, fontSize = 11.sp)
                        Text(formatMs(ps.duration), color = Muted, fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PillButton(speedLabel(ps.speed), active = ps.speed != 1.0f) { ps.cycleSpeed() }
                PillButton("-15s") { ps.seekRelative(-15_000L) }
                PillButton("+30s") { ps.seekRelative(30_000L) }
            }
        }
    }
}
