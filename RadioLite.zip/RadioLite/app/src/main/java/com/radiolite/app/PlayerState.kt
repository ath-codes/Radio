package com.radiolite.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController

enum class Status { Connecting, Live, Retrying, Paused }

/** Compose-friendly mirror of the player's state. */
class PlayerState(private val c: MediaController) : Player.Listener {
    var currentId by mutableStateOf(c.currentMediaItem?.mediaId)
    var playing by mutableStateOf(c.isPlaying)
    var wantsPlay by mutableStateOf(c.playWhenReady)
    var buffering by mutableStateOf(c.playbackState == Player.STATE_BUFFERING)
    var error by mutableStateOf(c.playerError != null)

    val status: Status
        get() = when {
            !wantsPlay -> Status.Paused
            error -> Status.Retrying
            playing -> Status.Live
            else -> Status.Connecting
        }

    fun attach() = c.addListener(this)
    fun detach() = c.removeListener(this)

    fun toggle() {
        if (wantsPlay) c.pause() else {
            if (c.playerError != null) c.prepare()
            c.play()
        }
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying; if (isPlaying) error = false }
    override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { wantsPlay = playWhenReady }
    override fun onPlaybackStateChanged(state: Int) {
        buffering = state == Player.STATE_BUFFERING
        if (state == Player.STATE_READY) error = false
    }
    override fun onPlayerError(e: PlaybackException) { error = true }
    override fun onMediaItemTransition(item: MediaItem?, reason: Int) { currentId = item?.mediaId; error = false }
}
