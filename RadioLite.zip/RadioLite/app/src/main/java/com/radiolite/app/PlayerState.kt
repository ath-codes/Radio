package com.radiolite.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController

enum class Status { Connecting, Live, Retrying, Paused }

/** Compose-friendly mirror of the player's state (live radio and podcasts). */
class PlayerState(private val c: MediaController) : Player.Listener {
    var currentId by mutableStateOf(c.currentMediaItem?.mediaId)
    var title by mutableStateOf(c.currentMediaItem?.mediaMetadata?.title?.toString() ?: "")
    var subtitle by mutableStateOf(c.currentMediaItem?.mediaMetadata?.artist?.toString() ?: "")
    var playing by mutableStateOf(c.isPlaying)
    var wantsPlay by mutableStateOf(c.playWhenReady)
    var buffering by mutableStateOf(c.playbackState == Player.STATE_BUFFERING)
    var error by mutableStateOf(c.playerError != null)
    var ended by mutableStateOf(c.playbackState == Player.STATE_ENDED)

    var position by mutableLongStateOf(c.currentPosition.coerceAtLeast(0L))
    var duration by mutableLongStateOf(c.duration.coerceAtLeast(0L))
    var speed by mutableFloatStateOf(c.playbackParameters.speed)

    val isPodcast: Boolean
        get() = currentId?.startsWith("ep_") == true

    val status: Status
        get() = when {
            !wantsPlay || ended -> Status.Paused
            error -> Status.Retrying
            playing -> Status.Live
            else -> Status.Connecting
        }

    fun attach() {
        c.addListener(this)
        syncProgress()
    }

    fun detach() = c.removeListener(this)

    fun syncProgress() {
        position = c.currentPosition.coerceAtLeast(0L)
        val d = c.duration
        duration = if (d > 0) d else 0L
    }

    fun toggle() {
        if (wantsPlay && !ended) c.pause() else {
            if (c.playerError != null) c.prepare()
            if (ended) c.seekTo(0L)
            c.play()
        }
    }

    fun seekTo(ms: Long) {
        c.seekTo(ms.coerceAtLeast(0L))
        position = ms.coerceAtLeast(0L)
    }

    fun seekRelative(deltaMs: Long) {
        val max = if (duration > 0) duration else Long.MAX_VALUE
        val target = (c.currentPosition + deltaMs).coerceIn(0L, max)
        c.seekTo(target)
        position = target
    }

    /** Stops playback and hides the player (the X button). */
    fun close() {
        ResumeStore.save(c)
        c.stop()
        c.clearMediaItems()
        currentId = null
        title = ""
        subtitle = ""
        playing = false
        ended = false
        error = false
        position = 0L
        duration = 0L
    }

    fun cycleSpeed() {
        val next = when (speed) {
            1.0f -> 1.25f
            1.25f -> 1.5f
            1.5f -> 2.0f
            else -> 1.0f
        }
        c.setPlaybackSpeed(next)
        speed = next
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) {
        playing = isPlaying
        if (isPlaying) error = false
        syncProgress()
    }

    override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
        wantsPlay = playWhenReady
    }

    override fun onPlaybackStateChanged(state: Int) {
        buffering = state == Player.STATE_BUFFERING
        ended = state == Player.STATE_ENDED
        if (state == Player.STATE_READY) error = false
        syncProgress()
    }

    override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
        speed = playbackParameters.speed
    }

    override fun onPlayerError(e: PlaybackException) {
        error = true
    }

    override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
        currentId = item?.mediaId
        title = item?.mediaMetadata?.title?.toString() ?: ""
        subtitle = item?.mediaMetadata?.artist?.toString() ?: ""
        error = false
        ended = false
        syncProgress()
    }

    override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
        mediaMetadata.title?.toString()?.let { if (it.isNotBlank()) title = it }
        mediaMetadata.artist?.toString()?.let { if (it.isNotBlank()) subtitle = it }
    }
}
