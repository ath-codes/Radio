@file:OptIn(UnstableApi::class)

package com.radiolite.app

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlin.math.min

/** Audio-only foreground playback: screen-off, auto-reconnect, sleep-timer fade-out. */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val handler = Handler(Looper.getMainLooper())
    private var retries = 0
    private var fadeStep = 0

    private val retryTask = Runnable {
        if (player.playWhenReady && player.mediaItemCount > 0) {
            if (!isPodcast()) {
                player.seekToDefaultPosition() // live stream: rejoin the live edge
            }
            // podcast: keep the current position and simply re-prepare
            player.prepare()
        }
    }

    private fun isPodcast() = player.currentMediaItem?.mediaId?.startsWith("ep_") == true

    /** Saves the podcast position every few seconds while playing. */
    private val saveTask = object : Runnable {
        override fun run() {
            if (player.isPlaying) ResumeStore.save(player)
            handler.postDelayed(this, 5_000)
        }
    }

    private val fadeTask = object : Runnable {
        override fun run() {
            fadeStep++
            player.volume = (1f - fadeStep / 20f).coerceAtLeast(0f)
            if (fadeStep < 20) {
                handler.postDelayed(this, 250)
            } else {
                player.pause()
                player.volume = 1f
                fadeStep = 0
            }
        }
    }

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            handler.post {
                if (player.playWhenReady && player.playerError != null) {
                    retries = 0
                    handler.removeCallbacks(retryTask)
                    player.prepare()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()

        ResumeStore.init(this)

        // podcast enclosures often redirect http -> https (trackers/CDNs): allow it
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent("RadioLite/1.0 (Android)")
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(15_000)

        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .setSeekBackIncrementMs(15_000)
            .setSeekForwardIncrementMs(30_000)
            .setLoadControl(
                DefaultLoadControl.Builder()
                    .setBufferDurationsMs(15_000, 30_000, 2_500, 5_000)
                    .build()
            )
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
            .also { p ->
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setMaxAudioChannelCount(2)
                    .build()
            }

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) retries = 0 else ResumeStore.save(player)
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    player.currentMediaItem?.mediaId?.let { ResumeStore.clear(it) }
                }
            }
            override fun onPlayerError(error: PlaybackException) {
                if (!player.playWhenReady) return
                // a dead podcast link should not retry forever
                if (isPodcast() && retries >= 6) {
                    retries = 0
                    player.pause()
                    return
                }
                val delayMs = min(1000L shl min(retries, 4), 15_000L)
                retries = min(retries + 1, 10)
                handler.removeCallbacks(retryTask)
                handler.postDelayed(retryTask, delayMs)
            }
        })
        handler.postDelayed(saveTask, 5_000)

        session = MediaSession.Builder(this, player)
            .setSessionActivity(
                PendingIntent.getActivity(
                    this, 0,
                    Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()

        setMediaNotificationProvider(
            DefaultMediaNotificationProvider(this).apply { setSmallIcon(R.drawable.ic_stat) }
        )

        SleepTimer.onFire = {
            handler.removeCallbacks(fadeTask)
            fadeStep = 0
            handler.post(fadeTask)
        }
        SleepTimer.onCancel = {
            handler.removeCallbacks(fadeTask)
            fadeStep = 0
            player.volume = 1f
        }

        runCatching {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.registerDefaultNetworkCallback(netCallback)
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!player.playWhenReady) stopSelf()
    }

    override fun onDestroy() {
        ResumeStore.save(player)
        handler.removeCallbacksAndMessages(null)
        runCatching {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.unregisterNetworkCallback(netCallback)
        }
        SleepTimer.onFire = null
        SleepTimer.onCancel = null
        session?.run {
            player.release()
            release()
            session = null
        }
        super.onDestroy()
    }
}
