package com.radiolite.app

import android.Manifest
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        f.addListener({ controller = runCatching { f.get() }.getOrNull() }, mainExecutor)
        setContent { RadioApp() }
    }

    override fun onDestroy() {
        controller?.release()
        super.onDestroy()
    }

    @Composable
    private fun RadioApp() {
        val ctx = LocalContext.current
        val ar = Locale.getDefault().language == "ar"
        var stations by remember { mutableStateOf(StationRepo.loadLocal(ctx)) }
        LaunchedEffect(Unit) { StationRepo.refresh(ctx)?.let { stations = it } }

        val ps = remember(controller) { controller?.let { PlayerState(it) } }
        DisposableEffect(ps) { ps?.attach(); onDispose { ps?.detach() } }

        val tabs = listOf("egypt" to R.string.tab_egypt, "qatar" to R.string.tab_qatar, "world" to R.string.tab_world)
        var tab by remember { mutableIntStateOf(0) }
        var genre by remember(tab) { mutableStateOf("all") }

        val inTab = stations.filter { it.tab == tabs[tab].first }
        val genres = listOf("all") + inTab.map { it.genre }.distinct()
        val shown = if (genre == "all") inTab else inTab.filter { it.genre == genre }
        val currentId = ps?.currentId

        MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Accent)) {
            Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
                Text(
                    stringResource(R.string.app_name), color = Color.White, fontSize = 28.sp,
                    fontWeight = FontWeight.Bold, modifier = Modifier.padding(22.dp, 18.dp, 22.dp, 10.dp)
                )
                TabRow(
                    selectedTabIndex = tab, containerColor = Bg, contentColor = Accent,
                    divider = { HorizontalDivider(color = Line) }
                ) {
                    tabs.forEachIndexed { i, (_, label) ->
                        Tab(
                            selected = tab == i, onClick = { tab = i },
                            text = {
                                Text(
                                    stringResource(label), fontSize = 15.sp,
                                    fontWeight = if (tab == i) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (tab == i) Accent else Muted
                                )
                            }
                        )
                    }
                }
                if (genres.size > 2) {
                    LazyRow(
                        contentPadding = PaddingValues(16.dp, 14.dp, 16.dp, 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(genres, key = { it }) { g ->
                            GenreChip(stringResource(genreLabel(g)), genre == g,
                                if (g == "all") Accent else genreColor(g)) { genre = g }
                        }
                    }
                }
                LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp, 14.dp, 16.dp, 20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(shown, key = { it.id }) { s ->
                        val on = currentId == s.id
                        StationCard(
                            name = s.name(ar), genre = s.genre, playable = s.playable, selected = on,
                            playing = ps?.playing == true, status = if (on) ps?.status else null
                        ) { if (on) ps?.toggle() else play(s, ar) }
                    }
                }
                AnimatedVisibility(
                    visible = currentId != null && ps != null,
                    enter = slideInVertically { it } + fadeIn(),
                    exit = slideOutVertically { it } + fadeOut()
                ) {
                    val cur = stations.firstOrNull { it.id == currentId }
                    if (ps != null) MiniPlayer(cur?.name(ar) ?: "", ps.status, ps.wantsPlay) { ps.toggle() }
                }
            }
        }
    }

    private fun play(s: Station, ar: Boolean) {
        val c = controller ?: return
        c.setMediaItem(
            MediaItem.Builder().setMediaId(s.id).setUri(s.url)
                .setMediaMetadata(
                    MediaMetadata.Builder().setTitle(s.name(ar)).setArtist(getString(R.string.app_name)).build()
                ).build()
        )
        c.prepare(); c.play()
    }
}
