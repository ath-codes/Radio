package com.radiolite.app

import android.Manifest
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.launch
import java.util.Locale

private enum class MainSection { RADIO, PODCASTS }

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ResumeStore.init(this)
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        f.addListener({ controller = runCatching { f.get() }.getOrNull() }, mainExecutor)
        setContent { RadioApp() }
    }

    override fun onStop() {
        controller?.let { ResumeStore.save(it) }
        super.onStop()
    }

    override fun onDestroy() {
        controller?.release()
        super.onDestroy()
    }

    @Composable
    private fun RadioApp() {
        val ctx = LocalContext.current
        val ar = Locale.getDefault().language == "ar"

        var stations by remember { mutableStateOf(StationRepo.loadLocal(ctx)) }
        var podcasts by remember { mutableStateOf(StationRepo.loadPodcasts(ctx)) }
        LaunchedEffect(Unit) {
            StationRepo.refresh(ctx)?.let { stations = it }
            StationRepo.refreshPodcasts(ctx)?.let { podcasts = it }
        }

        val ps = remember(controller) { controller?.let { PlayerState(it) } }
        DisposableEffect(ps) { ps?.attach(); onDispose { ps?.detach() } }

        var section by remember { mutableStateOf(MainSection.RADIO) }

        val radioTabs = listOf("all", "news", "quran", "talk", "sport", "music")
        var radioTabIndex by remember { mutableIntStateOf(0) }

        val podcastTabs = listOf("all", "geopolitics", "world", "history_philosophy")
        var podcastTabIndex by remember { mutableIntStateOf(0) }

        var selectedShow by remember { mutableStateOf<PodcastShow?>(null) }
        var episodes by remember { mutableStateOf<List<Episode>>(emptyList()) }
        var totalEpisodes by remember { mutableIntStateOf(0) }

        // list positions live here, so going back returns to the same place
        val radioListState = rememberLazyListState()
        val podcastListState = rememberLazyListState()
        LaunchedEffect(radioTabIndex) { radioListState.scrollToItem(0) }
        LaunchedEffect(podcastTabIndex) { podcastListState.scrollToItem(0) }
        var loadingEpisodes by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()

        BackHandler(enabled = selectedShow != null || section == MainSection.PODCASTS) {
            if (selectedShow != null) selectedShow = null else section = MainSection.RADIO
        }

        // (re)load the episode list whenever a show is opened; clear the old list first
        LaunchedEffect(selectedShow) {
            val show = selectedShow ?: return@LaunchedEffect
            episodes = emptyList()
            totalEpisodes = 0
            loadingEpisodes = true
            val r = StationRepo.fetchEpisodes(show, ar, force = false)
            episodes = r.episodes; totalEpisodes = r.total
            loadingEpisodes = false
        }

        val currentId = ps?.currentId

        MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Accent)) {
            Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
                Row(
                    Modifier.fillMaxWidth().padding(22.dp, 16.dp, 22.dp, 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (section == MainSection.RADIO) {
                            if (ar) "الراديو المباشر" else "Live Radio"
                        } else {
                            if (ar) "البودكاست" else "Podcasts"
                        },
                        color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold
                    )
                }

                Box(Modifier.weight(1f)) {
                    if (section == MainSection.RADIO) {
                        Column(Modifier.fillMaxSize()) {
                            CategoryTabs(radioTabs, radioTabIndex, ar) { radioTabIndex = it }

                            val activeCat = radioTabs[radioTabIndex]
                            val shownStations = if (activeCat == "all") stations else stations.filter { it.category == activeCat }

                            LazyColumn(
                                Modifier.fillMaxSize(),
                                state = radioListState,
                                contentPadding = PaddingValues(16.dp, 14.dp, 16.dp, 20.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(shownStations, key = { it.id }) { s ->
                                    val on = currentId == s.id
                                    StationCard(
                                        name = s.name(ar),
                                        category = s.category,
                                        ar = ar,
                                        playable = s.playable,
                                        selected = on,
                                        playing = ps?.playing == true,
                                        status = if (on) ps?.status else null
                                    ) {
                                        if (on) ps?.toggle() else playStation(s, ar)
                                    }
                                }
                            }
                        }
                    } else {
                        val show = selectedShow
                        if (show == null) {
                            Column(Modifier.fillMaxSize()) {
                                CategoryTabs(podcastTabs, podcastTabIndex, ar) { podcastTabIndex = it }

                                val activeCat = podcastTabs[podcastTabIndex]
                                val shownShows = if (activeCat == "all") podcasts else podcasts.filter { it.category == activeCat }

                                LazyColumn(
                                    Modifier.fillMaxSize(),
                                    state = podcastListState,
                                    contentPadding = PaddingValues(16.dp, 14.dp, 16.dp, 20.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    items(shownShows, key = { it.id }) { p ->
                                        PodcastShowCard(show = p, ar = ar) { selectedShow = p }
                                    }
                                }
                            }
                        } else {
                            Column(Modifier.fillMaxSize()) {
                                Row(
                                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier.clip(RoundedCornerShape(12.dp))
                                            .background(Card)
                                            .clickable { selectedShow = null }
                                            .padding(horizontal = 12.dp, vertical = 8.dp)
                                    ) {
                                        Text(
                                            if (ar) "▸ رجوع" else "◂ Back",
                                            color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Text(
                                        show.name(ar),
                                        color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Box(
                                        Modifier.clip(RoundedCornerShape(12.dp))
                                            .background(Card)
                                            .clickable(enabled = !loadingEpisodes) {
                                                scope.launch {
                                                    loadingEpisodes = true
                                                    val r = StationRepo.fetchEpisodes(show, ar, force = true)
                                                    episodes = r.episodes; totalEpisodes = r.total
                                                    loadingEpisodes = false
                                                }
                                            }
                                            .padding(horizontal = 10.dp, vertical = 8.dp)
                                    ) {
                                        Text(if (ar) "تحديث" else "Refresh", color = Muted, fontSize = 12.sp)
                                    }
                                }
                                HorizontalDivider(color = Line)
                                if (!loadingEpisodes && episodes.isNotEmpty()) {
                                    val shown = episodes.size
                                    val label = if (totalEpisodes > shown) {
                                        if (ar) "أحدث $shown من $totalEpisodes حلقة" else "Latest $shown of $totalEpisodes episodes"
                                    } else {
                                        if (ar) "$shown حلقة" else "$shown episodes"
                                    }
                                    Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp))
                                }

                                if (loadingEpisodes) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator(color = Accent)
                                    }
                                } else if (episodes.isEmpty()) {
                                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                                        Text(
                                            if (ar) "تعذر جلب الحلقات حالياً. تأكد من الاتصال بالإنترنت أو اضغط تحديث."
                                            else "Could not load episodes. Check connection or tap Refresh.",
                                            color = Muted, fontSize = 14.sp
                                        )
                                    }
                                } else {
                                    LazyColumn(
                                        Modifier.fillMaxSize(),
                                        contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 20.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        items(episodes, key = { it.id }) { ep ->
                                            val on = currentId == ep.id
                                            EpisodeCard(
                                                ep = ep,
                                                selected = on,
                                                playing = ps?.playing == true,
                                                status = if (on) ps?.status else null,
                                                ar = ar
                                            ) {
                                                if (on) ps?.toggle() else playEpisode(ep)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                AnimatedVisibility(
                    visible = currentId != null && ps != null,
                    enter = slideInVertically { it } + fadeIn(),
                    exit = slideOutVertically { it } + fadeOut()
                ) {
                    if (ps != null) {
                        val stName = stations.firstOrNull { it.id == currentId }?.name(ar)
                        MiniPlayer(name = stName ?: ps.title, ps = ps, ar = ar)
                    }
                }

                HorizontalDivider(color = Line)
                NavigationBar(containerColor = Card, contentColor = Color.White, tonalElevation = 0.dp) {
                    val itemColors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Accent,
                        selectedTextColor = Accent,
                        indicatorColor = Accent.copy(alpha = 0.15f),
                        unselectedIconColor = Muted,
                        unselectedTextColor = Muted
                    )
                    NavigationBarItem(
                        selected = section == MainSection.RADIO,
                        onClick = { section = MainSection.RADIO },
                        icon = { Text("📻", fontSize = 18.sp) },
                        label = {
                            Text(
                                if (ar) "الراديو" else "Radio",
                                fontWeight = if (section == MainSection.RADIO) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = itemColors
                    )
                    NavigationBarItem(
                        selected = section == MainSection.PODCASTS,
                        onClick = { section = MainSection.PODCASTS },
                        icon = { Text("🎙️", fontSize = 18.sp) },
                        label = {
                            Text(
                                if (ar) "البودكاست" else "Podcasts",
                                fontWeight = if (section == MainSection.PODCASTS) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = itemColors
                    )
                }
            }
        }
    }

    @Composable
    private fun CategoryTabs(tabs: List<String>, selected: Int, ar: Boolean, onSelect: (Int) -> Unit) {
        ScrollableTabRow(
            selectedTabIndex = selected,
            containerColor = Bg,
            contentColor = Accent,
            edgePadding = 16.dp,
            divider = { HorizontalDivider(color = Line) }
        ) {
            tabs.forEachIndexed { i, cat ->
                Tab(
                    selected = selected == i,
                    onClick = { onSelect(i) },
                    text = {
                        Text(
                            categoryLabelText(cat, ar),
                            fontSize = 14.sp,
                            fontWeight = if (selected == i) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (selected == i) Accent else Muted
                        )
                    }
                )
            }
        }
    }

    private fun playStation(s: Station, ar: Boolean) {
        val c = controller ?: return
        ResumeStore.save(c) // remember the podcast we are leaving
        c.setPlaybackSpeed(1.0f)
        c.setMediaItem(
            MediaItem.Builder().setMediaId(s.id).setUri(s.url)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(s.name(ar))
                        .setArtist(getString(R.string.app_name))
                        .build()
                ).build()
        )
        c.prepare(); c.play()
    }

    private fun playEpisode(ep: Episode) {
        val c = controller ?: return
        ResumeStore.save(c)
        val item = MediaItem.Builder().setMediaId(ep.id).setUri(ep.audioUrl)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(ep.title)
                    .setArtist(ep.showTitle)
                    .build()
            ).build()
        c.setMediaItem(item, ResumeStore.get(ep.id)) // resume where it stopped (0 = start)
        c.prepare(); c.play()
    }
}
