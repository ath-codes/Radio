package com.radiolite.app

import android.content.Context
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

data class Station(
    val id: String,
    val category: String,
    val nameAr: String,
    val nameEn: String,
    val url: String,
) {
    val playable: Boolean get() = url.startsWith("http")
    fun name(ar: Boolean): String =
        if (ar) nameAr.ifBlank { nameEn } else nameEn.ifBlank { nameAr }
}

data class PodcastShow(
    val id: String,
    val category: String,
    val nameAr: String,
    val nameEn: String,
    val rss: String,
) {
    fun name(ar: Boolean): String =
        if (ar) nameAr.ifBlank { nameEn } else nameEn.ifBlank { nameAr }
}

data class Episode(
    val id: String,
    val showTitle: String,
    val title: String,
    val audioUrl: String,
    val pubDate: String,
    val duration: String,
)

object StationRepo {
    private const val CACHE = "stations_cache.json"
    private const val MAX_EPISODES = 35
    private val rssCache = mutableMapOf<String, List<Episode>>()

    fun parse(text: String): List<Station> {
        val arr = JSONObject(text).getJSONArray("stations")
        val out = ArrayList<Station>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("id")
            if (id.isBlank()) continue
            val n = o.optJSONObject("name")
            val cat = o.optString("category").ifBlank {
                o.optString("genre").ifBlank { "news" }
            }
            out += Station(
                id = id,
                category = cat,
                nameAr = n?.optString("ar") ?: "",
                nameEn = n?.optString("en") ?: "",
                url = o.optString("url", "").trim(),
            )
        }
        return out
    }

    fun loadPodcasts(ctx: Context): List<PodcastShow> {
        val text = runCatching {
            ctx.assets.open("podcasts.json").bufferedReader().use { it.readText() }
        }.getOrNull() ?: return emptyList()

        return runCatching {
            val arr = JSONObject(text).getJSONArray("podcasts")
            val out = ArrayList<PodcastShow>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id")
                if (id.isBlank()) continue
                val n = o.optJSONObject("name")
                out += PodcastShow(
                    id = id,
                    category = o.optString("category", "geopolitics"),
                    nameAr = n?.optString("ar") ?: "",
                    nameEn = n?.optString("en") ?: "",
                    rss = o.optString("rss", "").trim()
                )
            }
            out
        }.getOrDefault(emptyList())
    }

    /** Opens [url] following redirects by hand (HttpURLConnection will not follow http<->https). */
    private fun openFollowing(url: String): HttpURLConnection? {
        var current = url
        for (hop in 0 until 6) {
            val c = (URL(current).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 15_000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", "RadioLite/1.0 (Android)")
                setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*")
            }
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc.isNullOrBlank()) return null
                current = URL(URL(current), loc).toString()
                continue
            }
            if (code in 200..299) return c
            c.disconnect()
            return null
        }
        return null
    }

    suspend fun fetchEpisodes(show: PodcastShow, ar: Boolean, force: Boolean = false): List<Episode> =
        withContext(Dispatchers.IO) {
            if (!force) rssCache[show.id]?.let { return@withContext it }
            runCatching {
                val c = openFollowing(show.rss) ?: return@runCatching emptyList<Episode>()
                try {
                    val list = parseRss(c.inputStream, show.id, show.name(ar))
                    if (list.isNotEmpty()) rssCache[show.id] = list
                    list
                } finally {
                    c.disconnect()
                }
            }.getOrDefault(emptyList())
        }

    private fun cleanDate(raw: String): String {
        val s = raw.trim()
        if (Regex("^\\d{4}-\\d{2}-\\d{2}.*").matches(s)) return s.take(10)      // Atom/ISO
        return s.replace(Regex("^[A-Za-z]+,\\s*"), "").take(11).trim()          // RFC-822
    }

    private fun parseRss(stream: InputStream, showId: String, showTitle: String): List<Episode> {
        val out = ArrayList<Episode>()
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(stream, null)

        var inItem = false
        var title = ""
        var audioUrl = ""
        var pubDate = ""
        var duration = ""
        var event = parser.eventType

        while (event != XmlPullParser.END_DOCUMENT && out.size < MAX_EPISODES) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val tag = parser.name.lowercase()
                    if (tag == "item" || tag == "entry") {
                        inItem = true
                        title = ""; audioUrl = ""; pubDate = ""; duration = ""
                    } else if (inItem) {
                        when (tag) {
                            "title" -> if (title.isBlank()) title = runCatching { parser.nextText().trim() }.getOrDefault("")
                            "enclosure" -> {
                                val u = parser.getAttributeValue(null, "url") ?: ""
                                val type = parser.getAttributeValue(null, "type") ?: ""
                                if (u.isNotBlank() && !type.startsWith("image") && !type.startsWith("video")) audioUrl = u.trim()
                            }
                            "media:content" -> if (audioUrl.isBlank()) {
                                val u = parser.getAttributeValue(null, "url") ?: ""
                                val type = parser.getAttributeValue(null, "type") ?: ""
                                if (u.isNotBlank() && (type.startsWith("audio") || u.contains(".mp3") || u.contains(".m4a"))) {
                                    audioUrl = u.trim()
                                }
                            }
                            "pubdate", "published", "updated" -> if (pubDate.isBlank()) {
                                pubDate = cleanDate(runCatching { parser.nextText() }.getOrDefault(""))
                            }
                            "itunes:duration" -> if (duration.isBlank()) {
                                duration = formatDuration(runCatching { parser.nextText().trim() }.getOrDefault(""))
                            }
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    val tag = parser.name.lowercase()
                    if ((tag == "item" || tag == "entry") && inItem) {
                        inItem = false
                        if (title.isNotBlank() && audioUrl.startsWith("http")) {
                            out += Episode(
                                // stable id: survives feed updates, so resume positions stay valid
                                id = "ep_${showId}_${Integer.toHexString(audioUrl.hashCode())}",
                                showTitle = showTitle,
                                title = title,
                                audioUrl = audioUrl,
                                pubDate = pubDate,
                                duration = duration
                            )
                        }
                    }
                }
            }
            event = parser.next()
        }
        return out.distinctBy { it.id }
    }

    private fun formatDuration(raw: String): String {
        if (raw.isBlank()) return ""
        if (raw.contains(":")) return raw
        val secs = raw.toLongOrNull() ?: return raw
        val h = secs / 3600
        val m = (secs % 3600) / 60
        val s = secs % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    private fun versionOf(text: String?): Int =
        if (text == null) -1 else runCatching { JSONObject(text).optInt("version", 0) }.getOrDefault(-1)

    fun loadLocal(ctx: Context): List<Station> {
        val asset = runCatching { ctx.assets.open("stations.json").bufferedReader().use { it.readText() } }.getOrNull()
        val cacheFile = File(ctx.filesDir, CACHE)
        val cached = if (cacheFile.exists()) runCatching { cacheFile.readText() }.getOrNull() else null
        val text = if (versionOf(cached) >= versionOf(asset)) cached ?: asset else asset
        return runCatching { parse(text ?: return emptyList()) }.getOrDefault(emptyList())
    }

    suspend fun refresh(ctx: Context): List<Station>? =
        withContext(Dispatchers.IO) {
            val u = BuildConfig.STATIONS_URL
            if (u.isBlank()) return@withContext null
            val asset = runCatching { ctx.assets.open("stations.json").bufferedReader().use { it.readText() } }.getOrNull()
            runCatching {
                val c = (URL(u).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000; readTimeout = 8000; useCaches = false
                }
                try {
                    if (c.responseCode != 200) return@runCatching null
                    val text = c.inputStream.bufferedReader().use { it.readText() }
                    // never let an older cloud copy override the bundled list
                    if (versionOf(text) < versionOf(asset)) return@runCatching null
                    val list = parse(text)
                    if (list.isEmpty()) null else { File(ctx.filesDir, CACHE).writeText(text); list }
                } finally { c.disconnect() }
            }.getOrNull()
        }
}
