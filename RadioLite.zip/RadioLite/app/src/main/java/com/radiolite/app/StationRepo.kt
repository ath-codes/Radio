package com.radiolite.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Station(
    val id: String,
    val tab: String,
    val genre: String,
    val nameAr: String,
    val nameEn: String,
    val url: String,
) {
    val playable: Boolean get() = url.startsWith("http")
    fun name(ar: Boolean): String =
        if (ar) nameAr.ifBlank { nameEn } else nameEn.ifBlank { nameAr }
}

/** Station list: bundled asset -> cached copy -> fresh copy from GitHub. */
object StationRepo {
    private const val CACHE = "stations_cache.json"

    fun parse(text: String): List<Station> {
        val arr = JSONObject(text).getJSONArray("stations")
        val out = ArrayList<Station>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("id")
            if (id.isBlank()) continue
            val n = o.optJSONObject("name")
            out += Station(
                id = id,
                tab = o.optString("tab", "world"),
                genre = o.optString("genre", ""),
                nameAr = n?.optString("ar") ?: "",
                nameEn = n?.optString("en") ?: "",
                url = o.optString("url", "").trim(),
            )
        }
        return out
    }

    private fun versionOf(text: String?): Int =
        if (text == null) -1 else runCatching { JSONObject(text).optInt("version", 0) }.getOrDefault(-1)

    fun loadLocal(ctx: Context): List<Station> {
        val asset = runCatching { ctx.assets.open("stations.json").bufferedReader().use { it.readText() } }.getOrNull()
        val cacheFile = File(ctx.filesDir, CACHE)
        val cached = if (cacheFile.exists()) runCatching { cacheFile.readText() }.getOrNull() else null
        val text = if (versionOf(cached) >= versionOf(asset)) cached ?: asset else asset
        return runCatching { parse(text ?: return emptyList()) }.getOrDefault(emptyList())
    }

    suspend fun refresh(ctx: Context): List<Station>? =
        withContext(Dispatchers.IO) {
            val u = BuildConfig.STATIONS_URL
            if (u.isBlank()) return@withContext null
            runCatching {
                val c = (URL(u).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000; readTimeout = 8000; useCaches = false
                }
                try {
                    if (c.responseCode != 200) return@runCatching null
                    val text = c.inputStream.bufferedReader().use { it.readText() }
                    val list = parse(text)
                    if (list.isEmpty()) null else { File(ctx.filesDir, CACHE).writeText(text); list }
                } finally { c.disconnect() }
            }.getOrNull()
        }
}
