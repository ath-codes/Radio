#!/usr/bin/env python3
"""Checks every stream and RSS link in the assets. Run: python3 tools/check_links.py"""
import json, sys, urllib.request, xml.etree.ElementTree as ET
A = "app/src/main/assets/"
UA = {"User-Agent": "RadioLite-check/1.0"}

def get(url, n=None, t=12):
    r = urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=t)
    return r, (r.read(n) if n else r.read())

bad = 0
for s in json.load(open(A + "stations.json"))["stations"]:
    try:
        r, b = get(s["url"], 2048)
        ok = r.status == 200 and len(b) > 0
        print(("OK  " if ok else "BAD ") + s["id"], r.headers.get("Content-Type", ""))
        bad += not ok
    except Exception as e:
        print("BAD ", s["id"], e); bad += 1
for p in json.load(open(A + "podcasts.json"))["podcasts"]:
    try:
        r, b = get(p["rss"])
        root = ET.fromstring(b)
        n = sum(1 for it in root.iter("item") if it.find("enclosure") is not None)
        print(("OK  " if n else "BAD ") + p["id"], f"{n} episodes with audio")
        bad += not n
    except Exception as e:
        print("BAD ", p["id"], e); bad += 1
sys.exit(1 if bad else 0)
